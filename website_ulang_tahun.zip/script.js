document.addEventListener("DOMContentLoaded", function() {
    Swal.fire({
        title: "Hai Sayang!",
        text: "Klik Love-nya dulu yaa 💕",
        imageUrl: "https://feeldreams.github.io/pandaputih.gif",
        imageWidth: 100,
        imageHeight: 100,
        showConfirmButton: true
    });
});

function startMessage() {
    document.getElementById("bgMusic").play();
    Swal.fire({
        title: "🎉 Selamat Ulang Tahun! 🎉",
        text: "Semoga harimu menyenangkan!",
        imageUrl: "https://feeldreams.github.io/wortel.gif",
        imageWidth: 100,
        imageHeight: 100,
        showConfirmButton: true
    });
}
